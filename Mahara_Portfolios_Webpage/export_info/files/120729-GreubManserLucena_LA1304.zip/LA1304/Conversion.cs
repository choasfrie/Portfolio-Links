﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LA1304
{
    public class Conversion
    {
        public string Convert(string input, string inputType, string outputType)
        {
            switch (inputType)
            {
                case "Hexadecimal":
                    switch (outputType)
                    {
                        case "Decimal":
                            return ToDecimal(input, inputType);
                        case "Binary":
                            return ToBinary(ToDecimal(input, inputType));
                    }
                    break;

                case "Binary":
                    switch (outputType)
                    {
                        case "Decimal":
                            return ToDecimal(input, inputType);
                        case "Hexadecimal":
                            return ToHexadecimal(ToDecimal(input, inputType));
                    }
                    break;

                default:
                    switch (outputType)
                    {
                        case "Binary":
                            return ToBinary(input);
                        case "Hexadecimal":
                            return ToHexadecimal(input);
                    }
                    break;

            }

            return "Wenn das da staht lösch ich mich + ich han irgend es problem";
        }

        public string ToDecimal(string input, string inputType)
        {

            double totalValue = 0;

            switch (inputType)
            {
                case "Hexadecimal":

                    for (int i = input.Length - 1; i >= 0; i--)
                    {
                        char hexDigit = input[i];
                        int decValue = 0;

                        if (hexDigit >= '0' && hexDigit <= '9')
                        {
                            decValue = hexDigit - '0';
                        }
                        else if (hexDigit >= 'A' && hexDigit <= 'F')
                        {
                            decValue = hexDigit - 'A' + 10; // -1 + 10
                        }

                        totalValue += decValue * Math.Pow(16, input.Length - 1 - i);
                    }
                    return totalValue.ToString();

                case "Binary":

                    for (int i = input.Length - 1; i >= 0; i--)
                    {
                        int currentDigit = input.Length - 1 - i;
                        char binaryDigit = input[i];
                        int decValue = 0;

                        decValue = binaryDigit - '0';

                        totalValue += decValue * Math.Pow(2, currentDigit);

                    }
                    return totalValue.ToString();


                default:
                    return "";
            }

        }

        public string ToHexadecimal(string input)
        {
            if (input == "0")
                return "0";

            int inputAsNumber = int.Parse(input);
            string hexadecimal = "";

            while (inputAsNumber > 0)
            {
                int remainder = inputAsNumber % 16;
                char hexDigit;
                if (remainder < 10)
                {
                    hexDigit = (char)(remainder + '0');
                }
                else
                {
                    hexDigit = (char)(remainder - 10 + 'A');
                }
                hexadecimal = hexDigit + hexadecimal;
                inputAsNumber /= 16;
            }

            return hexadecimal;

        }

        public string ToBinary(string input)
        {
            
            if (input == "0")
            {
                return "0";
            }

            int inputAsNumber = int.Parse(input);
            string binaryNumber = "";

            while (inputAsNumber > 0)
            {
                int remainder = inputAsNumber % 2;
                binaryNumber = remainder.ToString() + binaryNumber;
                inputAsNumber /= 2;
            }

            return binaryNumber;
        }
    }
}