﻿namespace LA1304
{
    partial class Startsite
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.background = new System.Windows.Forms.PictureBox();
            this.buttonTest = new System.Windows.Forms.Button();
            this.labelTest = new System.Windows.Forms.Label();
            this.dropdownInput = new System.Windows.Forms.ComboBox();
            this.dropdownOutput = new System.Windows.Forms.ComboBox();
            this.textInput = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.background)).BeginInit();
            this.SuspendLayout();
            // 
            // background
            // 
            this.background.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.background.Location = new System.Drawing.Point(-5, 0);
            this.background.Name = "background";
            this.background.Size = new System.Drawing.Size(806, 457);
            this.background.TabIndex = 0;
            this.background.TabStop = false;
            this.background.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // buttonTest
            // 
            this.buttonTest.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTest.Location = new System.Drawing.Point(363, 392);
            this.buttonTest.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonTest.Name = "buttonTest";
            this.buttonTest.Size = new System.Drawing.Size(110, 38);
            this.buttonTest.TabIndex = 1;
            this.buttonTest.Text = "OK";
            this.buttonTest.UseVisualStyleBackColor = false;
            this.buttonTest.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelTest
            // 
            this.labelTest.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelTest.Location = new System.Drawing.Point(267, 212);
            this.labelTest.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTest.Name = "labelTest";
            this.labelTest.Size = new System.Drawing.Size(295, 28);
            this.labelTest.TabIndex = 2;
            this.labelTest.Text = ".";
            this.labelTest.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelTest.Click += new System.EventHandler(this.label1_Click);
            // 
            // dropdownInput
            // 
            this.dropdownInput.FormattingEnabled = true;
            this.dropdownInput.Items.AddRange(new object[] {
            "Hexadecimal",
            "Binary",
            "Decimal"});
            this.dropdownInput.Location = new System.Drawing.Point(144, 115);
            this.dropdownInput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dropdownInput.Name = "dropdownInput";
            this.dropdownInput.Size = new System.Drawing.Size(171, 33);
            this.dropdownInput.TabIndex = 5;
            this.dropdownInput.Text = "Input auswählen";
            this.dropdownInput.SelectedIndexChanged += new System.EventHandler(this.dropdownInput_SelectedIndexChanged);
            // 
            // dropdownOutput
            // 
            this.dropdownOutput.FormattingEnabled = true;
            this.dropdownOutput.Items.AddRange(new object[] {
            "Hexadecimal",
            "Binary",
            "Decimal"});
            this.dropdownOutput.Location = new System.Drawing.Point(523, 115);
            this.dropdownOutput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dropdownOutput.Name = "dropdownOutput";
            this.dropdownOutput.Size = new System.Drawing.Size(171, 33);
            this.dropdownOutput.TabIndex = 6;
            this.dropdownOutput.Text = "Output auswählen";
            this.dropdownOutput.SelectedIndexChanged += new System.EventHandler(this.dropdownInput_SelectedIndexChanged);
            // 
            // textInput
            // 
            this.textInput.Location = new System.Drawing.Point(292, 287);
            this.textInput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textInput.Name = "textInput";
            this.textInput.Size = new System.Drawing.Size(255, 31);
            this.textInput.TabIndex = 7;
            this.textInput.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Startsite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textInput);
            this.Controls.Add(this.dropdownOutput);
            this.Controls.Add(this.dropdownInput);
            this.Controls.Add(this.labelTest);
            this.Controls.Add(this.buttonTest);
            this.Controls.Add(this.background);
            this.Name = "Startsite";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.background)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox background;
        private Button buttonTest;
        private Label labelTest;
        private ComboBox dropdownInput;
        private ComboBox dropdownOutput;
        private TextBox textInput;
    }
}