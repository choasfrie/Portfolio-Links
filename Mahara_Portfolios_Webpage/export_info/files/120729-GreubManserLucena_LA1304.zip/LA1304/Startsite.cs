using System.CodeDom;

namespace LA1304
{
    public partial class Startsite : Form
    {
        private string inputType = string.Empty;
        private string outputType = string.Empty;
        private string input = string.Empty;

        public Startsite()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (inputType == string.Empty && outputType == string.Empty && input == string.Empty)
            {
                labelTest.Text = "Select input- and output type and choose a value to calculate";
                return;
            }
            input = textInput.Text;

            try
            {
                if(inputType == outputType)
                {
                    labelTest.Text = input;
                    return;
                }
                Conversion conversion = new Conversion();
                labelTest.Text = conversion.Convert(input, inputType, outputType);

            }
            catch
            {
                labelTest.Text = "Number couldn't be converted";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dropdownInput_SelectedIndexChanged(object sender, EventArgs e)
        {
            inputType = dropdownInput.Text;
            outputType = dropdownOutput.Text;
        }
    }
}